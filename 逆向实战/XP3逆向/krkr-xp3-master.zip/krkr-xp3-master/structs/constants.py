XP3Signature = b'XP3\x0D\x0A\x20\x0A\x1A\x8B\x67\x01'
XP3FileIndexContinue = 0x80
XP3FileIndexCompressed = 0x01
Xp3FileIndexUncompressed = 0x00
XP3FileIsEncrypted = 1 << 31
